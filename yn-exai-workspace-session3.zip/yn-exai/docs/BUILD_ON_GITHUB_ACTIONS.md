# Build the baseline APK from a phone (GitHub Actions)

Why: the Claude sandbox has no network/SDK and 3 GB RAM. A GitHub-hosted runner has network, Ubuntu, and enough RAM/disk. For public repos Actions minutes are free. Nothing here needs a PC.

## Steps
1. Sign in to github.com and create a NEW PUBLIC repository (any name, e.g. `yn-exai-build`). It only holds the workflow; the source is cloned from the official host at run time.
2. In the repo: Add file > Create new file. Name it exactly `.github/workflows/build-lemon-baseline.yml` (typing the slashes makes the folders). Paste the full contents of `ci/build-lemon-baseline.yml`. Commit.
3. Open the Actions tab > `build-lemon-baseline` > Run workflow (keep defaults: tag `v1.2.2`, prefix `5f172bd0af`). If the button is missing in the mobile browser, turn on "Desktop site".
4. Wait for the run. Duration is unmeasured; plan for hours, not minutes (timeout is 5 h).
5. Open the finished run > Artifacts. Download `evidence` (always uploaded, even on failure) and `apk-baseline` (only on success). Send `evidence` back to Claude.

## What the workflow proves, and what it does not
- Proves: the tag resolved to a commit starting with `5f172bd0af` in a clone made from git.lemon-emu.org (the job aborts otherwise); submodules were fetched; the binary/license/red-flag scan ran; the APK hashes come from that run.
- Does not prove: that the source is safe or that every dependency license is compatible (needs review of the evidence), or that the APK works on your phone.

## Before installing the APK
- It is signed with a local/debug key, not Lemon's release key. If its applicationId equals an installed official Lemon, Android refuses the update or forces an uninstall, which deletes app data. Check `evidence/redflags.txt` (applicationId section) and back up saves from the official app first.
- Do not install any APK whose SHA-256 differs from `evidence/apk_sha256.txt`.

## If the build fails
`evidence/build.log` holds the Gradle error. Likely causes: wrong NDK/CMake version, release signing config needing a keystore, out-of-disk, a dependency host unreachable. Send the last ~150 lines and the `toolchain.txt`.
