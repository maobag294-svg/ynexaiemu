# Benchmark protocol (baseline before any optimization)
Conditions: same build, same driver, same settings file, device at room temperature, battery 50-100%, airplane mode optional, brightness fixed, no charging, background apps closed.
Scene: a repeatable 5-minute route in a legally owned game (save state or fixed save). Discard first 30 s (warmup) and the first run after a reboot or driver change.
Runs: >= 3 per configuration, interleaved (A B A B A B) to spread thermal drift.
Capture per run: frame times (the emulator's own frame-time log if available, else SurfaceFlinger latency), `scripts/05_sample_telemetry.sh <label> 300`, logcat.
Analyze: `python3 -m ynexai.cli metrics runs/<label>/frames.csv --warmup 900`, `thermal runs/<label>/telemetry.csv`, `doctor runs/<label>/logcat.txt`.
Compare: ynexai.compare (needs >= 3 runs; effects under 3% or inside 2x run noise are reported as "no measurable change").
Report measured results and hypotheses separately. Do not report averages alone: include 1% low and stutters/min.
