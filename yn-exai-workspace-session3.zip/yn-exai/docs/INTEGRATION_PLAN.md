# From analysis core to in-app features
The Python in tools/ynexai is the reference spec, tested offline. In-app versions are Kotlin (UI/telemetry) plus a small C++ hook for frame times. Hook points below are TO CONFIRM against the cloned source.

| Module | Real input | In-app form | Milestone |
|---|---|---|---|
| Performance Director | frame times from emulator frame timer | Kotlin port of metrics.py/director.py; panel in quick-game menu | M5a |
| Thermal & Stability Guard | PowerManager thermal status/headroom APIs + sysfs when readable | Kotlin; advisory only (no silent changes) | M5b |
| Smart Shader Manager | pipeline-cache stats and compile events from renderer logs | confirm log strings, then port shader.py; cache tools must never touch save data | M5c |
| Game Profile Optimizer | stored benchmark runs per game | recommends, user confirms; per-game config via existing per-game settings | M5d |
| Game Doctor | logcat/emulator log | port doctor.py rule table; exportable report | M5e |
| Graphics Optimizer | frame times + user limits | port adaptive.step(); needs a runtime resolution-scale setter in the renderer: confirm it exists | M5f |

Frame generation: separate optional experimental toggle, never mixed into native FPS counters; show latency/artifact warning.
Local LLM: not in scope until a measured RAM/power/latency budget exists; core stays offline and deterministic.

## Overlay (Phase 4)
Assets in branding/android. Next: read the existing overlay classes (InputOverlay*, drawable names, JSON/prefs for layouts), map drawables 1:1, then test pressed states, 48dp touch targets, opacity slider, per-game layout save.
