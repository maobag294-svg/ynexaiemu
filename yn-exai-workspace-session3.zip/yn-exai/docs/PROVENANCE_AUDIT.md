# Provenance and license audit

## Verified (from official pages)
- Lemon: GPLv3-or-later; README says fork of Eden; Eden derives from yuzu and Sudachi (GPLv3+).
- No keys/firmware shipped (README statement; confirm with scan: "key material" section must print `none`).

## Unverified until the scan runs
- Repo contents, commit authenticity beyond the release-page hash, tag signature (likely unsigned).
- Whether `externals/` and cpmfile.json deps all have GPL-compatible licenses (read state/provenance/cpm_dependencies.txt + each dep's license).
- Origin and license of bundled binaries, especially "Lemon-Ade" driver and any prebuilt .so (state/provenance/binary_sha256.txt). Rule: a binary without public source and license is removed from the YN.EXAI build.
- Name collisions: "LEMON" is also a graph library (BSL-1.0) and an old Citra fork; GitHub copies (Ghael-V mirror, certier fork) can be stale. Always clone from git.lemon-emu.org and check the hash.

## Features to remove or gate for YN.EXAI
- "Lemon Lite & Spoofed": renames the package so phones boost it as a benchmark app. Deceptive; delete the flavor.
- Nextendo Network: third-party online service dependency; disable by default or remove.
- Lossless Scaling engine option: loads a user-supplied Windows DLL; audit what this actually does on Android before keeping.
- Memory editor/macros: product decision; keep out of the first release.

## Decision gates (Lemon stays the base only if all pass)
1. Both repos build with the same toolchain.
2. `lemon_only_commits` and Mali commit list (state/mali_commits.txt) show Mali changes that are understandable and not entangled with removed features. If they are small and separable, switch to Eden + cherry-picks.
3. Baseline on Mali-G615 MC6 is not worse than Eden on identical scene/settings.
4. Every bundled binary has a source and a GPL-compatible license, or is removed.

## Legal
Copyleft: YN.EXAI must be released under GPL with source. Nintendo has pursued emulator projects and forks; the GPL does not remove that risk. Get qualified legal advice before any public release. No keys, firmware, or game files in repo, CI, or issue attachments.
