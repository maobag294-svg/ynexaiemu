# YN.EXAI: progress and handoff

Resume by uploading this folder/zip. Last updated: session 3 (2026-10-26).

## Decision on record
Base candidate: Lemon v1.2.2 (official: git.lemon-emu.org/lemon/Lemon-Project), Eden as comparison. Provisional until the gates in docs/PROVENANCE_AUDIT.md pass.

## Status table (evidence-based)
| Item | Status | Evidence |
|---|---|---|
| Session-1 zip complete | CONFIRMED | re-extracted: 33 files, 19/19 tests pass, 7 shell scripts pass `bash -n` |
| Official repo cloned | NO | sandbox DNS fails (git.lemon-emu.org, github.com unresolved); repo pages not fetchable |
| Commit 5f172bd0af verified from a clone | NO | only seen on the official releases page next to tag v1.2.2; not checked against a clone |
| Submodules/dependencies fetched | NO | needs network |
| License and binary audit | NO | scripts ready; needs the clone |
| Baseline APK | NO | no SDK/NDK/CMake/Gradle, 1 CPU, 3 GB RAM here |
| Mali-G615 optimization or benchmark | NO | nothing measured |

## What session 2 added
- ci/build-lemon-baseline.yml: single-file GitHub Actions workflow (clone official repo, abort unless the tag resolves to the expected commit, scan provenance, install JDK 17 + the project's NDK + CMake 3.22.1, build, hash APK, upload evidence always). YAML parses; every shell block passes `bash -n`; the commit-check logic was tested on a local repo (match exits 0, mismatch exits 2). The workflow as a whole has NOT run: untested on a real runner, pinned only to major action versions.
- docs/BUILD_ON_GITHUB_ACTIONS.md: phone-only steps.

## Environment facts
- Target device (user-reported): Infinix X6873, Android 16, Dimensity 8350 Ultimate, Mali-G615 MC6. Not probed yet.
- Claude sandbox: no network, JDK runtime only (no javac), no Gradle/CMake/SDK/NDK, 1 CPU, 3 GB RAM, no adb.

## Next actions (in order)
1. USER: run the workflow (docs/BUILD_ON_GITHUB_ACTIONS.md), download `evidence`, upload it to the next session. If the build succeeds, keep `apk-baseline` and its SHA-256.
2. CLAUDE: read evidence/commit_verification.txt first. Mark the commit VERIFIED only if it says so there. Review binary_sha256, redflags, license_files, cpmfile, lineage, mali_commits.
3. Decide Lemon vs Eden with the four gates. Then strip Spoofed flavor, Nextendo, Lossless path, unaudited drivers.
4. USER: run scripts/04_device_probe.sh with adb (or a Vulkan info app JSON export) and the baseline protocol in docs/BENCHMARK_PROTOCOL.md.
5. Only then: branding applied to real source, Mali changes one at a time with before/after, Kotlin port of ynexai modules.

## Session 3: workflow run attempt (2026-10-26)
- Result: NOT RUN. Claude has no tool that can create a GitHub repo, push a file, trigger a workflow, or read run results. The sandbox has no network, and a connector-directory search (github, actions, repository, workflow) returned no GitHub connector.
- Therefore: no run URL, no build log, no APK, no SHA-256, and the commit is still unverified from a clone. Nothing about the build is claimed.
- Unchanged: ci/build-lemon-baseline.yml (sha256 3083fcac...e29598) is the file to upload as-is.
- First hard blocker: a GitHub account action that only the user can perform (create repo, add file, press Run workflow).

### Run log (fill in; paste back next session)
| Field | Value |
|---|---|
| Repo URL | |
| Run URL | |
| Started / finished (UTC) | |
| Conclusion (success/failure/cancelled) | |
| First failing step name | |
| Artifacts present (evidence / apk-baseline) | |
