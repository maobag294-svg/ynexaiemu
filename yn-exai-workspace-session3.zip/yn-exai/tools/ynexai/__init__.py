"""YN.EXAI deterministic analysis core. Offline, no cloud, no ML. Operates on exported telemetry."""
__version__ = "0.1.0"
