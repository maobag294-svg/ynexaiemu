"""Before/after comparison with a noise guard. Needs >=3 runs per side; otherwise result is labeled 'inconclusive'."""
import statistics as st

def compare(before_runs, after_runs, key="avg_fps", min_runs=3, min_effect_pct=3.0):
    """before_runs/after_runs: lists of summarize() dicts (higher is better for fps keys, lower for *_ms/stutters)."""
    b = [r[key] for r in before_runs]; a = [r[key] for r in after_runs]
    if min(len(a), len(b)) < min_runs:
        return {"key": key, "verdict": "inconclusive", "reason": f"need >= {min_runs} runs per side"}
    mb, ma = st.mean(b), st.mean(a)
    delta = (ma - mb) / mb * 100.0 if mb else float("nan")
    noise = max(st.pstdev(b), st.pstdev(a))
    higher_better = not (key.endswith("_ms") or key.startswith("stutters") or key == "jitter_ms")
    improved = (delta > 0) == higher_better
    outside_noise = abs(ma - mb) > 2 * noise
    if abs(delta) < min_effect_pct or not outside_noise:
        verdict = "no measurable change"
    else:
        verdict = "improved" if improved else "regressed"
    return {"key": key, "before_mean": round(mb, 3), "after_mean": round(ma, 3), "delta_pct": round(delta, 2),
            "run_noise": round(noise, 3), "verdict": verdict}
