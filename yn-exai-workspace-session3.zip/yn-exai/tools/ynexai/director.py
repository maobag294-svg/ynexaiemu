"""AI Performance Director: turns a metrics summary into prioritized, evidence-linked observations."""

def advise(summary, target_fps=30.0):
    out = []; avg = summary["avg_fps"]
    if avg < target_fps * 0.95:
        out.append(("high", f"Average {avg} fps is below the {target_fps:.0f} fps target: GPU- or CPU-bound; check utilisation counters before changing settings."))
    if summary["fps_1pct_low"] < 0.7 * avg:
        out.append(("high", f"1% low ({summary['fps_1pct_low']}) is far below average ({avg}): uneven frame pacing, look at stutter sources."))
    if summary["stutters_per_min"] > 6:
        out.append(("medium", f"{summary['stutters_per_min']} stutters/min: correlate with shader events (shader.py) and GC/IO in logcat."))
    if summary["jitter_ms"] > 0.25 * summary["p50_ms"]:
        out.append(("medium", "Frame-time jitter is high relative to median: try frame-pacing/FPS cap and compare."))
    if not out: out.append(("info", "No rule triggered. Compare against baseline using compare.py rather than judging in isolation."))
    return out
