"""AI Graphics Optimizer: adaptive resolution controller with user-defined limits, hysteresis and cooldown.
Pure function so it is unit-testable; the app calls step() once per second with recent frame times."""
from dataclasses import dataclass

@dataclass
class Limits:
    min_scale: float = 0.6
    max_scale: float = 1.0
    step: float = 0.05
    target_fps: float = 30.0
    down_below: float = 0.92   # scale down if 5th-worst frame rate < target*0.92
    up_above: float = 1.10     # scale up only if comfortably above target
    cooldown_s: int = 5

def step(recent_frame_ms, scale, since_change_s, lim: Limits = Limits()):
    """Returns (new_scale, reason). Never leaves [min_scale, max_scale]. Refuses to act on <20 frames."""
    if len(recent_frame_ms) < 20: return scale, "insufficient data"
    if since_change_s < lim.cooldown_s: return scale, "cooldown"
    s = sorted(recent_frame_ms); p95 = s[int(len(s) * 0.95) - 1]
    fps_low = 1000.0 / p95
    if fps_low < lim.target_fps * lim.down_below and scale > lim.min_scale:
        return round(max(lim.min_scale, scale - lim.step), 3), f"p95 {fps_low:.1f}fps below target"
    if fps_low > lim.target_fps * lim.up_above and scale < lim.max_scale:
        return round(min(lim.max_scale, scale + lim.step), 3), f"headroom: p95 {fps_low:.1f}fps"
    return scale, "hold"
