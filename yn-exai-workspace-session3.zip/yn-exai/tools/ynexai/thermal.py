"""AI Thermal & Stability Guard (deterministic). Detects throttling risk from telemetry.csv produced by 05_sample_telemetry.sh.
Zone names and safe limits differ per device: thresholds are parameters, not claims about the Dimensity 8350."""
import csv, collections, statistics as st

def load(path):
    zones = collections.defaultdict(list); freqs = collections.defaultdict(list); batt = {}
    with open(path, newline="") as f:
        for r in csv.DictReader(f):
            t = int(r["t_s"])
            try: zones[r["zone"]].append((t, int(r["temp_mC"]) / 1000.0))
            except (ValueError, KeyError): pass
            for k in ("cpu7_khz", "cpu4_khz", "cpu0_khz"):
                if r.get(k, "").isdigit(): freqs[(k, t)] = int(r[k])
            if r.get("battery_temp_dC", "").isdigit(): batt[t] = int(r["battery_temp_dC"]) / 10.0
    return zones, freqs, batt

def analyze(path, warn_c=42.0, hot_c=46.0, freq_drop_pct=15.0, slope_warn_c_per_min=1.0):
    zones, freqs, batt = load(path)
    out = {"findings": [], "level": "ok"}
    # 1. battery/skin proxy
    if batt:
        ts = sorted(batt); vals = [batt[t] for t in ts]
        out["battery_max_c"] = max(vals)
        if len(ts) > 60:
            slope = (st.mean(vals[-30:]) - st.mean(vals[:30])) / ((ts[-1] - ts[0]) / 60.0)
            out["battery_slope_c_per_min"] = round(slope, 2)
            if slope > slope_warn_c_per_min: out["findings"].append(f"battery temp rising {slope:.2f} C/min (not yet stable)")
        if max(vals) >= hot_c: out["level"] = "hot"
        elif max(vals) >= warn_c and out["level"] == "ok": out["level"] = "warm"
    # 2. frequency collapse: compare first-minute median vs last-minute median per cluster
    for k in ("cpu7_khz", "cpu4_khz", "cpu0_khz"):
        series = sorted((t, v) for (kk, t), v in freqs.items() if kk == k)
        if len(series) < 120: continue
        first = st.median(v for _, v in series[:60]); last = st.median(v for _, v in series[-60:])
        drop = (first - last) / first * 100.0 if first else 0.0
        if drop >= freq_drop_pct:
            out["findings"].append(f"{k}: median freq fell {drop:.0f}% between first and last minute (possible throttling or governor change)")
            if out["level"] != "hot": out["level"] = "throttling-suspected"
    out["recommendations"] = recommend(out["level"])
    return out

def recommend(level):
    table = {
        "ok": [],
        "warm": ["Consider an FPS cap one step below native for long sessions.", "Re-measure with the same scene after the change."],
        "throttling-suspected": ["Lower FPS cap or resolution scale one step and repeat the run.", "Compare 1% low FPS, not only average FPS, before and after."],
        "hot": ["Pause heavy workloads; reduce resolution scale and FPS cap, let the device cool before re-testing."],
    }
    return table[level]
