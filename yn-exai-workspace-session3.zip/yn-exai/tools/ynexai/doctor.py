"""AI Game Doctor (rule-based). Each rule maps log evidence to likely causes. Output is a hypothesis, never a verdict."""
import re

RULES = [
    (r"VK_ERROR_DEVICE_LOST", "GPU device lost", ["Driver crash or GPU timeout (hang)", "Invalid resource use or missing barrier", "Thermal/power event"], "Re-run with validation layers or driver logs; note the last draw/dispatch before the loss."),
    (r"VK_ERROR_OUT_OF_DEVICE_MEMORY|VK_ERROR_OUT_OF_HOST_MEMORY", "Vulkan out of memory", ["Texture/buffer pressure", "Resolution scale too high", "Leak across sessions"], "Lower resolution scale; compare memory use per scene (dumpsys meminfo)."),
    (r"VK_ERROR_INITIALIZATION_FAILED|vkCreateDevice.*fail|VK_ERROR_INCOMPATIBLE_DRIVER", "Vulkan init failure", ["Custom driver incompatible with this GPU/OS", "Missing required extension/feature"], "Switch back to the system driver and retry; record driver version."),
    (r"VK_ERROR_EXTENSION_NOT_PRESENT|VK_ERROR_FEATURE_NOT_PRESENT", "Missing Vulkan feature", ["Emulator expects a feature this driver lacks"], "Check device probe vkjson for the named feature."),
    (r"SIGSEGV|Fatal signal 11", "Native crash (SIGSEGV)", ["Null/invalid pointer in native code", "Driver bug"], "Collect tombstone from /data/tombstones or bugreport; symbolicate libs from the relWithDebInfo build."),
    (r"SIGABRT|Fatal signal 6", "Native abort", ["Failed assertion", "Uncaught exception", "Vulkan abort"], "Look at the lines before the abort for the assertion text."),
    (r"lowmemorykiller|Out of memory: Kill|OutOfMemoryError|am_kill", "Process killed for memory", ["System memory pressure", "Large guest heap + cache"], "Close background apps; compare PSS over time."),
    (r"shader.*(error|fail)|SPIR-V.*(error|invalid)|spirv-val", "Shader translation/validation error", ["Unsupported guest shader feature", "Translator bug"], "Record the game, shader hash, and driver; test with another driver."),
    (r"pipeline cache.*(corrupt|invalid|mismatch)", "Pipeline cache rejected", ["Driver/app update invalidated cache", "Truncated file"], "Clear that game's shader cache only (never save data)."),
    (r"Thermal.*(throttl|critical|shutdown)|thermal status\s*[3-6]", "Thermal event", ["Sustained load causing throttling"], "Run the thermal analyzer and lower FPS cap/resolution scale."),
]
_COMPILED = [(re.compile(p, re.I), t, c, n) for p, t, c, n in RULES]

def diagnose(lines, max_evidence=3):
    findings = {}
    for ln in lines:
        for rx, title, causes, nxt in _COMPILED:
            if rx.search(ln):
                f = findings.setdefault(title, {"title": title, "likely_causes": causes, "next_step": nxt, "evidence": [], "count": 0})
                f["count"] += 1
                if len(f["evidence"]) < max_evidence: f["evidence"].append(ln.strip()[:200])
    return sorted(findings.values(), key=lambda f: -f["count"])
