"""Smart Shader Manager analysis: correlates frame-time stutters with shader/pipeline log events.
The log pattern is a parameter: confirm the real Lemon/Eden log strings after the first build (state/provenance + logcat)."""
import re
from .metrics import stutter_indices

DEFAULT_PATTERN = re.compile(r"(pipeline|shader).*(compil|build|creat|cache)|(compil|build|creat|cache).*(pipeline|shader)", re.I)

def correlate(frame_ms, frame_t_ms, log_events, pattern=DEFAULT_PATTERN, window_ms=250):
    """frame_t_ms: timestamp of each frame; log_events: list of (t_ms, text). Returns stutters explained by compile events."""
    idx = stutter_indices(frame_ms)
    hits = [(t, s) for t, s in log_events if pattern.search(s)]
    explained = []
    for i in idx:
        t = frame_t_ms[i]
        if any(abs(t - th) <= window_ms for th, _ in hits): explained.append(i)
    return {"stutters": len(idx), "near_shader_events": len(explained),
            "explained_pct": round(100.0 * len(explained) / len(idx), 1) if idx else 0.0,
            "shader_events_total": len(hits)}

def repeat_compilations(log_lines, key_regex=r"(hash|key|pipeline)[ =:]+([0-9a-fA-Fx]{6,})"):
    """Same key compiled more than once in one session suggests a cache miss/invalidations. Returns {key: count>1}."""
    seen = {}
    rx = re.compile(key_regex, re.I)
    for line in log_lines:
        if not DEFAULT_PATTERN.search(line): continue
        m = rx.search(line)
        if m: seen[m.group(2).lower()] = seen.get(m.group(2).lower(), 0) + 1
    return {k: v for k, v in seen.items() if v > 1}
