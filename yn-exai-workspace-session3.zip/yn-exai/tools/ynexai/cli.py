import argparse, json, sys
from . import metrics, director, thermal, doctor

def main(argv=None):
    p = argparse.ArgumentParser(prog="ynexai")
    sub = p.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("metrics"); a.add_argument("csv"); a.add_argument("--warmup", type=int, default=0); a.add_argument("--target", type=float, default=30.0)
    b = sub.add_parser("thermal"); b.add_argument("csv")
    c = sub.add_parser("doctor"); c.add_argument("log")
    args = p.parse_args(argv)
    if args.cmd == "metrics":
        s = metrics.summarize(metrics.load_frame_ms(args.csv), args.warmup)
        print(json.dumps({"summary": s, "advice": director.advise(s, args.target)}, indent=2))
    elif args.cmd == "thermal":
        print(json.dumps(thermal.analyze(args.csv), indent=2))
    else:
        print(json.dumps(doctor.diagnose(open(args.log, errors="replace")), indent=2))

if __name__ == "__main__": main()
