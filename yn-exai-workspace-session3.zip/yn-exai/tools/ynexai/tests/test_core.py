"""All data here is SYNTHETIC. These tests validate code logic only; they say nothing about any device or game."""
import unittest, random, tempfile, os, csv
from ynexai import metrics, compare, thermal, shader, doctor, profile, adaptive, director

def steady(n=1800, ms=33.3, jitter=0.5, seed=1):
    r = random.Random(seed); return [ms + r.uniform(-jitter, jitter) for _ in range(n)]

class TestMetrics(unittest.TestCase):
    def test_avg_fps_steady_30(self):
        s = metrics.summarize(steady()); self.assertAlmostEqual(s["avg_fps"], 30.0, delta=0.5); self.assertEqual(s["stutters"], 0)
    def test_stutters_detected(self):
        ft = steady(); 
        for i in (300, 700, 1200): ft[i] = 120.0
        s = metrics.summarize(ft); self.assertEqual(s["stutters"], 3); self.assertLess(s["fps_0p1pct_low"], 15)
    def test_too_few_frames(self):
        with self.assertRaises(ValueError): metrics.summarize([16.0] * 10)
    def test_load_t_ms(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "t.csv")
            with open(p, "w", newline="") as f:
                w = csv.writer(f); w.writerow(["t_ms"]); [w.writerow([i * 16.667]) for i in range(100)]
            ft = metrics.load_frame_ms(p); self.assertEqual(len(ft), 99); self.assertAlmostEqual(ft[0], 16.667, places=2)

class TestCompare(unittest.TestCase):
    def runs(self, ms, n=3): return [metrics.summarize(steady(ms=ms, seed=i)) for i in range(n)]
    def test_improvement(self):
        r = compare.compare(self.runs(33.3), self.runs(28.0)); self.assertEqual(r["verdict"], "improved")
    def test_regression(self):
        r = compare.compare(self.runs(28.0), self.runs(33.3)); self.assertEqual(r["verdict"], "regressed")
    def test_noise_not_claimed(self):
        r = compare.compare(self.runs(33.3), self.runs(33.2)); self.assertEqual(r["verdict"], "no measurable change")
    def test_needs_runs(self):
        r = compare.compare(self.runs(33.3, 1), self.runs(28.0, 1)); self.assertEqual(r["verdict"], "inconclusive")
    def test_lower_is_better_for_stutters(self):
        b = [{"stutters_per_min": 10.0 + i} for i in range(3)]; a = [{"stutters_per_min": 2.0 + i} for i in range(3)]
        self.assertEqual(compare.compare(b, a, key="stutters_per_min")["verdict"], "improved")

class TestThermal(unittest.TestCase):
    def write(self, d, hot=False, drop=False, n=300):
        p = os.path.join(d, "telemetry.csv")
        with open(p, "w", newline="") as f:
            w = csv.writer(f); w.writerow(["t_s", "zone", "temp_mC", "battery_temp_dC", "cpu7_khz", "cpu4_khz", "cpu0_khz"])
            for t in range(n):
                bt = 300 + (t * (0.8 if hot else 0.0)); f7 = 3200000 if not (drop and t > n // 2) else 2400000
                w.writerow([t, "soc", 45000, int(bt), f7, 2800000, 2000000])
        return p
    def test_ok(self):
        with tempfile.TemporaryDirectory() as d: self.assertEqual(thermal.analyze(self.write(d))["level"], "ok")
    def test_throttle_detected(self):
        with tempfile.TemporaryDirectory() as d:
            r = thermal.analyze(self.write(d, drop=True)); self.assertEqual(r["level"], "throttling-suspected"); self.assertTrue(r["findings"])
    def test_hot(self):
        with tempfile.TemporaryDirectory() as d: self.assertEqual(thermal.analyze(self.write(d, hot=True))["level"], "hot")

class TestShader(unittest.TestCase):
    def test_correlation(self):
        ft = steady(n=600); ft[300] = 150.0
        t = [0.0]; [t.append(t[-1] + v) for v in ft[:-1]]
        r = shader.correlate(ft, t, [(t[300] - 40, "Compiling pipeline 0xabcdef")]); self.assertEqual(r["near_shader_events"], 1)
    def test_repeat(self):
        lines = ["Compiling pipeline hash=0xabc123", "Compiling pipeline hash=0xabc123", "Compiling pipeline hash=0xdef456"]
        self.assertEqual(shader.repeat_compilations(lines), {"0xabc123": 2})

class TestDoctor(unittest.TestCase):
    def test_rules(self):
        r = doctor.diagnose(["E vulkan: VK_ERROR_DEVICE_LOST in submit", "F libc: Fatal signal 11 (SIGSEGV)"])
        self.assertEqual({f["title"] for f in r}, {"GPU device lost", "Native crash (SIGSEGV)"})
    def test_clean_log(self): self.assertEqual(doctor.diagnose(["I all good"]), [])

class TestProfile(unittest.TestCase):
    def test_pick_and_reject(self):
        mk = lambda ms, n=3: [metrics.summarize(steady(ms=ms, seed=i)) for i in range(n)]
        r = profile.recommend({"1.0x": mk(40.0), "0.8x": mk(33.0), "0.6x": mk(33.0, 2)}, target_fps=30)
        self.assertEqual(r["recommended"], "0.8x"); self.assertFalse([x for x in r["table"] if x["config"] == "0.6x"][0]["eligible"])

class TestAdaptive(unittest.TestCase):
    def test_down_up_hold_limits(self):
        slow = [40.0] * 60; fast = [20.0] * 60; ok = [32.0] * 60; L = adaptive.Limits()
        self.assertEqual(adaptive.step(slow, 1.0, 10)[0], 0.95)
        self.assertEqual(adaptive.step(slow, 0.6, 10)[0], 0.6)           # floor
        self.assertEqual(adaptive.step(fast, 1.0, 10)[0], 1.0)           # ceiling
        self.assertEqual(adaptive.step(fast, 0.8, 10)[0], 0.85)
        self.assertEqual(adaptive.step(ok, 0.8, 10)[1], "hold")
        self.assertEqual(adaptive.step(slow, 1.0, 1)[1], "cooldown")
        self.assertEqual(adaptive.step([40.0] * 5, 1.0, 10)[1], "insufficient data")

class TestDirector(unittest.TestCase):
    def test_flags(self):
        ft = steady(); 
        for i in range(100, 1700, 40): ft[i] = 110.0
        adv = director.advise(metrics.summarize(ft)); self.assertTrue(any(p == "medium" or p == "high" for p, _ in adv))

if __name__ == "__main__": unittest.main()
