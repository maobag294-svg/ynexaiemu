"""AI Game Profile Optimizer: picks among MEASURED configurations. It never invents settings and never applies without consent."""
import statistics as st

def recommend(runs_by_config, target_fps=30.0, min_runs=3, max_stutters_per_min=6.0, thermal_ok=None):
    """runs_by_config: {config_name: [summary dicts]}. thermal_ok: optional {config_name: bool}.
    Rule: eligible = enough runs, mean 1% low >= 0.8*target, stutters within limit, thermal ok.
    Rank by (resolution score is user-defined elsewhere) -> here: highest mean 1% low, then lowest jitter."""
    rows = []
    for name, runs in runs_by_config.items():
        if len(runs) < min_runs:
            rows.append({"config": name, "eligible": False, "why": f"only {len(runs)} runs (need {min_runs})"}); continue
        low = st.mean(r["fps_1pct_low"] for r in runs); avg = st.mean(r["avg_fps"] for r in runs)
        sp = st.mean(r["stutters_per_min"] for r in runs); jit = st.mean(r["jitter_ms"] for r in runs)
        why = []
        if low < 0.8 * target_fps: why.append(f"1% low {low:.1f} < {0.8*target_fps:.1f}")
        if sp > max_stutters_per_min: why.append(f"stutters/min {sp:.1f} > {max_stutters_per_min}")
        if thermal_ok is not None and not thermal_ok.get(name, False): why.append("thermal check failed or missing")
        rows.append({"config": name, "eligible": not why, "why": "; ".join(why), "avg_fps": round(avg, 1), "low1": round(low, 1), "stutters_per_min": round(sp, 1), "jitter": round(jit, 2)})
    ok = sorted([r for r in rows if r["eligible"]], key=lambda r: (-r["low1"], r["jitter"]))
    return {"recommended": ok[0]["config"] if ok else None, "table": rows,
            "note": "Recommendation only. Valid for the tested scene, build and driver."}
