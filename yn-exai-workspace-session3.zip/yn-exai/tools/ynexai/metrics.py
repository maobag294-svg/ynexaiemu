"""Frame-time metrics. Input CSV needs a column frame_ms, or t_ms (monotonic timestamps)."""
import csv, statistics as st

def load_frame_ms(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    if not rows: raise ValueError("empty file")
    if "frame_ms" in rows[0]:
        return [float(r["frame_ms"]) for r in rows]
    if "t_ms" in rows[0]:
        t = [float(r["t_ms"]) for r in rows]
        return [b - a for a, b in zip(t, t[1:])]
    raise ValueError("need frame_ms or t_ms column")

def pct(sorted_vals, p):
    if not sorted_vals: raise ValueError("no data")
    k = (len(sorted_vals) - 1) * p / 100.0
    lo, hi = int(k), min(int(k) + 1, len(sorted_vals) - 1)
    return sorted_vals[lo] + (sorted_vals[hi] - sorted_vals[lo]) * (k - lo)

def stutter_indices(ft, window=30, factor=2.0, floor_ms=8.0):
    """A frame is a stutter if > factor x rolling median of the previous `window` frames and > floor_ms above it."""
    out = []
    for i, v in enumerate(ft):
        prev = ft[max(0, i - window):i]
        if len(prev) < 5: continue
        m = st.median(prev)
        if v > factor * m and v - m > floor_ms: out.append(i)
    return out

def summarize(ft, warmup_frames=0):
    ft = ft[warmup_frames:]
    if len(ft) < 30: raise ValueError("need at least 30 frames")
    s = sorted(ft); total_s = sum(ft) / 1000.0
    worst1 = s[int(len(s) * 0.99):] or s[-1:]
    worst01 = s[int(len(s) * 0.999):] or s[-1:]
    return {
        "frames": len(ft), "duration_s": round(total_s, 2),
        "avg_fps": round(len(ft) / total_s, 2),
        "p50_ms": round(pct(s, 50), 2), "p95_ms": round(pct(s, 95), 2), "p99_ms": round(pct(s, 99), 2),
        "fps_1pct_low": round(1000.0 / (sum(worst1) / len(worst1)), 2),
        "fps_0p1pct_low": round(1000.0 / (sum(worst01) / len(worst01)), 2),
        "jitter_ms": round(st.pstdev(ft), 2),
        "stutters": len(stutter_indices(ft)),
        "stutters_per_min": round(len(stutter_indices(ft)) / (total_s / 60.0), 2),
    }
