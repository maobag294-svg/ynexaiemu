YN.EXAI workspace. Start with PROGRESS.md.
Run order: scripts/00_env_check.sh -> 01_fetch_and_verify.sh -> 02_provenance_scan.sh -> 03_build.sh -> 04_device_probe.sh.
Tests: cd tools && python3 -m unittest ynexai.tests.test_core
