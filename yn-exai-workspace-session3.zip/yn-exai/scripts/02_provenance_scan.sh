#!/usr/bin/env bash
# License inventory, prebuilt-binary manifest, red-flag grep. Read-only.
source "$(dirname "$0")/common.sh"
cd "$SRC"; OUT="$ROOT/state/provenance"; mkdir -p "$OUT"
git ls-files -z | xargs -0 file --mime-type 2>/dev/null | grep -Ev 'text/|inode/x-empty|image/(png|jpeg|svg)' > "$OUT/non_text_files.txt" || true
git ls-files | grep -Ei '\.(so|a|jar|aar|apk|dll|exe|bin|zip|7z|dex|ttf|otf|dat)$' | while read -r f; do printf '%s  %s\n' "$(sha256sum "$f" | cut -d' ' -f1)" "$f"; done > "$OUT/binary_sha256.txt" || true
git ls-files | grep -Ei '(^|/)(LICENSE|COPYING|NOTICE|LICENSES/|\.reuse/)' > "$OUT/license_files.txt" || true
if [ -f cpmfile.json ]; then python3 - <<'PY' > "$OUT/cpm_dependencies.txt"
import json
d=json.load(open("cpmfile.json"))
for k,v in sorted(d.items()):
    print(k, {x:v[x] for x in ("repo","tag","hash","sha","artifact","url","git_version","version") if isinstance(v,dict) and x in v})
PY
fi
{
 echo "## spoof / benchmark package names"; grep -rIniE 'spoof|antutu|geekbench' --include='*.kt' --include='*.xml' --include='*.kts' --include='*.cpp' --include='*.h' --include='*.json' . | head -40 || true
 echo "## external endpoints"; grep -rIohE 'https?://[A-Za-z0-9./_?=&%-]+' --include='*.kt' --include='*.cpp' --include='*.h' --include='*.xml' . | sort | uniq -c | sort -rn | head -60 || true
 echo "## online/telemetry"; grep -rIniE 'nextendo|telemetry|analytics|crashlytics|firebase' --include='*.kt' --include='*.cpp' --include='*.kts' --include='*.xml' . | head -40 || true
 echo "## Windows DLL / Lossless"; grep -rIniE 'Lossless\.dll|LoadLibrary' --include='*.kt' --include='*.cpp' . | head -20 || true
 echo "## key material in tree (must be none)"; git ls-files | grep -Ei 'prod\.keys|title\.keys|\.keys$|firmware' || echo none
 echo "## bundled drivers"; git ls-files | grep -Ei 'lemon-?ade|adrenotools|driver' | head -20 || true
} > "$OUT/redflags.txt"
head -150 "$OUT/redflags.txt"; log "provenance scan -> $OUT"
