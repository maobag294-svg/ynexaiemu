#!/usr/bin/env bash
# Baseline APK. Command from Lemon's README; confirm flags with .ci/android/build.sh --help.
source "$(dirname "$0")/common.sh"
: "${ANDROID_SDK_ROOT:?set ANDROID_SDK_ROOT}"; : "${ANDROID_NDK_ROOT:?set ANDROID_NDK_ROOT (NDK 27+)}"
command -v java >/dev/null || { echo "JDK 17 required"; exit 3; }
cd "$SRC/src/android"
LOG="$LOGS/build_$(stamp).log"; log "building -> $LOG"
./gradlew --console=plain assembleMainlineRelWithDebInfo 2>&1 | tee "$LOG"
find . -name '*.apk' -exec sha256sum {} \; | tee "$ROOT/state/apk_sha256.txt"
log "baseline build done (not a signed release)"
