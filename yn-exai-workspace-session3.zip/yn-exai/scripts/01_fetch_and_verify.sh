#!/usr/bin/env bash
# Clone official repo, pin to the tag, verify the commit, record lineage against Eden.
source "$(dirname "$0")/common.sh"
mkdir -p "$ROOT/src"
if [ ! -d "$SRC/.git" ]; then log "cloning $LEMON_URL"; git clone --recursive "$LEMON_URL" "$SRC" 2>&1 | tee -a "$LOGS/clone.log"; fi
cd "$SRC"
git fetch --tags --force
git checkout --detach "tags/$LEMON_TAG"
git submodule update --init --recursive 2>&1 | tee -a "$LOGS/clone.log" || true
HEAD_SHA="$(git rev-parse HEAD)"
case "$HEAD_SHA" in
  ${LEMON_COMMIT_PREFIX}*) log "OK commit matches pinned prefix: $HEAD_SHA" ;;
  *) log "FAIL: $LEMON_TAG -> $HEAD_SHA, expected ${LEMON_COMMIT_PREFIX}*. STOP, do not build."; exit 2 ;;
esac
git verify-tag "$LEMON_TAG" 2>&1 | tee -a "$LOGS/verify_tag.log" || log "note: tag not GPG-signed or key unknown"
git remote get-url eden >/dev/null 2>&1 || git remote add eden "$EDEN_URL"
git fetch eden --no-tags 2>&1 | tee -a "$LOGS/eden_fetch.log" || log "WARN: Eden remote unreachable; use a mirror you trust"
{
  echo "head=$HEAD_SHA"; echo "tag=$LEMON_TAG"; echo "date=$(date -u +%FT%TZ)"
  echo "total_commits=$(git rev-list --count HEAD)"
  EDEN_REF="$(git for-each-ref --format='%(refname)' refs/remotes/eden | grep -E '/(master|main)$' | head -1 || true)"
  if [ -n "$EDEN_REF" ]; then
    MB="$(git merge-base HEAD "$EDEN_REF" || true)"; echo "eden_ref=$EDEN_REF merge_base=$MB"
    [ -n "$MB" ] && { echo "lemon_only_commits=$(git rev-list --count "$MB"..HEAD)"; git diff --shortstat "$MB" HEAD; }
  else echo "eden_ref=unavailable"; fi
} | tee "$ROOT/state/lineage.txt"
git log --no-merges -i --grep='mali' --grep='astc' --grep='BCn' --grep='panvk' --pretty='%h %ad %s' --date=short | tee "$ROOT/state/mali_commits.txt" | head -40
git ls-files | grep -Ei 'astc|bcn|mali|recompress' | tee "$ROOT/state/mali_files.txt" | head -40
