#!/usr/bin/env bash
# Pinned facts come from the official release page (git.lemon-emu.org), checked 2026-10-26.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LOGS="$ROOT/logs"; mkdir -p "$LOGS"
LEMON_URL="https://git.lemon-emu.org/lemon/Lemon-Project.git"
LEMON_TAG="v1.2.2"
LEMON_COMMIT_PREFIX="5f172bd0af"
EDEN_URL="https://git.eden-emu.dev/eden-emu/eden"
SRC="$ROOT/src/Lemon-Project"
stamp() { date -u +%Y%m%dT%H%M%SZ; }
log()  { echo "[$(date -u +%H:%M:%S)] $*" | tee -a "$LOGS/session.log"; }
