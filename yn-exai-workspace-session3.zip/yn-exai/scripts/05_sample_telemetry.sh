#!/usr/bin/env bash
# Usage: 05_sample_telemetry.sh <label> <seconds>. Run while the test scene plays.
source "$(dirname "$0")/common.sh"
LABEL="${1:?label}"; SECS="${2:-300}"; OUT="$ROOT/state/runs/$LABEL"; mkdir -p "$OUT"
adb logcat -c; adb logcat -v threadtime > "$OUT/logcat.txt" & LPID=$!
echo "t_s,zone,temp_mC,battery_temp_dC,cpu7_khz,cpu4_khz,cpu0_khz" > "$OUT/telemetry.csv"
for ((i=0;i<SECS;i++)); do
  adb shell "b=\$(dumpsys battery | grep -m1 temperature | tr -dc 0-9); f7=\$(cat /sys/devices/system/cpu/cpu7/cpufreq/scaling_cur_freq 2>/dev/null); f4=\$(cat /sys/devices/system/cpu/cpu4/cpufreq/scaling_cur_freq 2>/dev/null); f0=\$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq 2>/dev/null); for z in /sys/class/thermal/thermal_zone*; do echo \"$i,\$(cat \$z/type),\$(cat \$z/temp 2>/dev/null),\$b,\$f7,\$f4,\$f0\"; done" | tr -d '\r' >> "$OUT/telemetry.csv"
  sleep 1
done
kill $LPID 2>/dev/null || true; log "telemetry -> $OUT"
