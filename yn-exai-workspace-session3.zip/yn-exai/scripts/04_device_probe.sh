#!/usr/bin/env bash
# Records what the device reports. Nothing about the Mali driver is assumed.
source "$(dirname "$0")/common.sh"
command -v adb >/dev/null || { echo "adb missing"; exit 3; }
OUT="$ROOT/state/device_$(stamp)"; mkdir -p "$OUT"
adb shell getprop > "$OUT/getprop.txt"
for p in ro.product.model ro.board.platform ro.hardware.vulkan ro.build.version.release ro.build.version.sdk; do echo "$p=$(adb shell getprop $p | tr -d '\r')"; done | tee "$OUT/summary.txt"
adb shell cmd gpu vkjson > "$OUT/vkjson.json" 2>"$OUT/vkjson.err" || echo "vkjson unavailable; export JSON from a Vulkan info app" | tee -a "$OUT/summary.txt"
adb shell dumpsys thermalservice > "$OUT/thermalservice.txt" 2>&1 || true
adb shell 'ls /sys/class/thermal | head -60' > "$OUT/thermal_index.txt" 2>&1 || true
echo "saved: $OUT"
