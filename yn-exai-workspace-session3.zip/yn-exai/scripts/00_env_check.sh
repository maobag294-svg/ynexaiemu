#!/usr/bin/env bash
source "$(dirname "$0")/common.sh"
out="$LOGS/env_$(stamp).txt"
{
  echo "== host =="; uname -a; nproc; free -g | sed -n 1,2p; df -h . | tail -1
  echo "== tools =="
  for t in git java javac cmake ninja python3 adb curl; do printf '%-8s' "$t"; (command -v "$t" >/dev/null && "$t" --version 2>&1 | head -1) || echo MISSING; done
  echo "== android env =="; echo "ANDROID_SDK_ROOT=${ANDROID_SDK_ROOT:-unset}"; echo "ANDROID_NDK_ROOT=${ANDROID_NDK_ROOT:-unset}"
  echo "== network =="; (timeout 8 git ls-remote "$LEMON_URL" HEAD >/dev/null 2>&1 && echo "lemon git: reachable") || echo "lemon git: UNREACHABLE"
} | tee "$out"
echo "Needs (Lemon README): JDK 17, NDK 27+, CMake 3.22.1. Plan on 16 GB RAM and 30 GB disk."
